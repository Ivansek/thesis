var Node = function(name, x, y, conns)
{
	this.name = name;
	this.x = x;
	this.y = y;
	this.connections = conns;
}